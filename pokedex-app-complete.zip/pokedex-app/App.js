import 'react-native-gesture-handler';
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { StatusBar } from 'expo-status-bar';

import TabNavigator from './src/navigation/TabNavigator';
import SettingsScreen from './src/screens/SettingsScreen';
import HelpScreen from './src/screens/HelpScreen';
import LogoutScreen from './src/screens/LogoutScreen';

const Drawer = createDrawerNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <StatusBar style="dark" />
      <Drawer.Navigator
        initialRouteName="Pokedex"
        screenOptions={{
          headerTintColor: '#DC0A2D',
          drawerActiveTintColor: '#DC0A2D',
        }}
      >
        {/* The tabs (Home + About) live inside the drawer */}
        <Drawer.Screen name="Pokedex" component={TabNavigator} options={{ title: 'Pokedex' }} />
        <Drawer.Screen name="Settings" component={SettingsScreen} />
        <Drawer.Screen name="Help and Support" component={HelpScreen} />
        <Drawer.Screen name="Logout" component={LogoutScreen} />
      </Drawer.Navigator>
    </NavigationContainer>
  );
}
