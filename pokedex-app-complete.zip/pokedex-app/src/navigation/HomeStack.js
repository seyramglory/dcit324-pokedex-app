import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';

import HomeScreen from '../screens/HomeScreen';
import DetailsScreen from '../screens/DetailsScreen';

const Stack = createStackNavigator();

export default function HomeStack() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: '#DC0A2D' },
        headerTintColor: '#fff',
        headerTitleStyle: { fontWeight: '700' },
      }}
    >
      <Stack.Screen
        name="PokemonList"
        component={HomeScreen}
        options={{ title: 'Pokedex' }}
      />
      <Stack.Screen
        name="PokemonDetails"
        component={DetailsScreen}
        options={({ route }) => ({
          title: route.params?.name
            ? route.params.name.charAt(0).toUpperCase() + route.params.name.slice(1)
            : 'Details',
        })}
      />
    </Stack.Navigator>
  );
}
