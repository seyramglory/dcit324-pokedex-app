import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

// A reusable "dumb" component: it only knows what it's told through props.
// name, image, number -> what to display
// isFavourite, onToggleFavourite -> favourite state, controlled by the parent
// onPress -> what happens when the card itself is tapped
export default function PokemonCard({
  name,
  image,
  number,
  isFavourite,
  onToggleFavourite,
  onPress,
}) {
  return (
    <TouchableOpacity style={styles.card} onPress={onPress} activeOpacity={0.75}>
      <Image source={{ uri: image }} style={styles.image} resizeMode="contain" />

      <View style={styles.info}>
        <Text style={styles.number}>#{String(number).padStart(3, '0')}</Text>
        <Text style={styles.name}>{name}</Text>
      </View>

      <TouchableOpacity
        onPress={onToggleFavourite}
        style={styles.favouriteButton}
        hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
      >
        <Ionicons
          name={isFavourite ? 'heart' : 'heart-outline'}
          size={24}
          color={isFavourite ? '#DC0A2D' : '#9AA0A6'}
        />
      </TouchableOpacity>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F5F5F7',
    borderRadius: 14,
    padding: 10,
    marginVertical: 6,
    marginHorizontal: 16,
  },
  image: {
    width: 56,
    height: 56,
    marginRight: 12,
  },
  info: {
    flex: 1,
  },
  number: {
    fontSize: 12,
    color: '#9AA0A6',
  },
  name: {
    fontSize: 16,
    fontWeight: '600',
    textTransform: 'capitalize',
    color: '#222',
  },
  favouriteButton: {
    padding: 8,
  },
});
