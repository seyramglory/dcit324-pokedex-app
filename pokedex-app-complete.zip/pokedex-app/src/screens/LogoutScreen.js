import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function LogoutScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Logout</Text>
      <Text style={styles.body}>
        This is a placeholder — since the app has no login system, there's
        nothing to log out of yet. Wire this up to real auth logic later if
        needed.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 24 },
  title: { fontSize: 22, fontWeight: '700', marginBottom: 12, color: '#222' },
  body: { fontSize: 15, color: '#444' },
});
