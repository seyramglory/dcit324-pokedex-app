import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  Image,
  ActivityIndicator,
  ScrollView,
  StyleSheet,
} from 'react-native';

export default function DetailsScreen({ route }) {
  const { id } = route.params;

  const [details, setDetails] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    fetchDetails();
  }, [id]);

  const fetchDetails = async () => {
    try {
      setLoading(true);
      setError(false);

      const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${id}`);
      if (!response.ok) throw new Error('Request failed');

      const data = await response.json();
      setDetails(data);
    } catch (err) {
      setError(true);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" color="#DC0A2D" />
      </View>
    );
  }

  if (error || !details) {
    return (
      <View style={styles.centered}>
        <Text style={styles.errorText}>Couldn't load this Pokemon's details.</Text>
      </View>
    );
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Image
        source={{ uri: details.sprites?.front_default }}
        style={styles.image}
        resizeMode="contain"
      />

      <Text style={styles.name}>{details.name}</Text>
      <Text style={styles.number}>#{String(details.id).padStart(3, '0')}</Text>

      <View style={styles.typesRow}>
        {details.types.map((t) => (
          <View key={t.type.name} style={styles.typeBadge}>
            <Text style={styles.typeText}>{t.type.name}</Text>
          </View>
        ))}
      </View>

      <View style={styles.statsRow}>
        <View style={styles.statBox}>
          <Text style={styles.statLabel}>Height</Text>
          {/* PokeAPI gives height in decimetres, weight in hectograms */}
          <Text style={styles.statValue}>{details.height / 10} m</Text>
        </View>
        <View style={styles.statBox}>
          <Text style={styles.statLabel}>Weight</Text>
          <Text style={styles.statValue}>{details.weight / 10} kg</Text>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    padding: 24,
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  errorText: {
    fontSize: 15,
    color: '#DC0A2D',
    textAlign: 'center',
  },
  image: {
    width: 160,
    height: 160,
  },
  name: {
    fontSize: 24,
    fontWeight: '700',
    textTransform: 'capitalize',
    marginTop: 8,
    color: '#222',
  },
  number: {
    fontSize: 14,
    color: '#9AA0A6',
    marginBottom: 20,
  },
  typesRow: {
    flexDirection: 'row',
    marginBottom: 24,
  },
  typeBadge: {
    backgroundColor: '#DC0A2D',
    borderRadius: 16,
    paddingVertical: 6,
    paddingHorizontal: 16,
    marginHorizontal: 4,
  },
  typeText: {
    color: '#fff',
    fontWeight: '600',
    textTransform: 'capitalize',
    fontSize: 13,
  },
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '100%',
  },
  statBox: {
    alignItems: 'center',
    backgroundColor: '#F5F5F7',
    borderRadius: 14,
    padding: 16,
    width: '42%',
  },
  statLabel: {
    fontSize: 12,
    color: '#9AA0A6',
  },
  statValue: {
    fontSize: 18,
    fontWeight: '700',
    marginTop: 4,
    color: '#222',
  },
});
