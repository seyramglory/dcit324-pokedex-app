import React, { useEffect, useState } from 'react';
import { View, FlatList, ActivityIndicator, Text, StyleSheet } from 'react-native';

import PokemonCard from '../components/PokemonCard';

const POKEMON_LIMIT = 30; // how many Pokemon to show on the Home screen

export default function HomeScreen({ navigation }) {
  const [pokemonList, setPokemonList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [favourites, setFavourites] = useState({}); // { [id]: true/false }

  useEffect(() => {
    fetchPokemon();
  }, []);

  const fetchPokemon = async () => {
    try {
      setLoading(true);
      setError(false);

      const response = await fetch(
        `https://pokeapi.co/api/v2/pokemon?limit=${POKEMON_LIMIT}`
      );
      if (!response.ok) throw new Error('Request failed');

      const data = await response.json();

      // The list endpoint only gives us name + url, so we derive the id
      // from its position and build a sprite image URL from that id.
      const formatted = data.results.map((item, index) => {
        const id = index + 1;
        return {
          id,
          name: item.name,
          image: `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${id}.png`,
        };
      });

      setPokemonList(formatted);
    } catch (err) {
      setError(true);
    } finally {
      setLoading(false);
    }
  };

  const toggleFavourite = (id) => {
    setFavourites((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  if (loading) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" color="#DC0A2D" />
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.centered}>
        <Text style={styles.errorText}>
          Couldn't load Pokemon. Check your connection and try again.
        </Text>
      </View>
    );
  }

  return (
    <FlatList
      data={pokemonList}
      keyExtractor={(item) => item.id.toString()}
      contentContainerStyle={{ paddingVertical: 10 }}
      renderItem={({ item }) => (
        <PokemonCard
          name={item.name}
          image={item.image}
          number={item.id}
          isFavourite={!!favourites[item.id]}
          onToggleFavourite={() => toggleFavourite(item.id)}
          onPress={() =>
            navigation.navigate('PokemonDetails', { id: item.id, name: item.name })
          }
        />
      )}
    />
  );
}

const styles = StyleSheet.create({
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  errorText: {
    fontSize: 15,
    color: '#DC0A2D',
    textAlign: 'center',
  },
});
