import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function HelpScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Help and Support</Text>
      <Text style={styles.body}>
        Need help? This is where support information or an FAQ would live.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 24 },
  title: { fontSize: 22, fontWeight: '700', marginBottom: 12, color: '#222' },
  body: { fontSize: 15, color: '#444' },
});
