import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function AboutScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>About this app</Text>
      <Text style={styles.body}>
        This Pokedex app was built with React Native and Expo for DCIT 324.
        It fetches live Pokemon data from PokeAPI (pokeapi.co) and lets you
        browse Pokemon, mark favourites, and view details like type, height,
        and weight.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 24, justifyContent: 'center' },
  title: { fontSize: 22, fontWeight: '700', marginBottom: 12, color: '#222' },
  body: { fontSize: 15, lineHeight: 22, color: '#444' },
});
