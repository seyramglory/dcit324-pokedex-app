# Pokedex App — DCIT 324 Assignment 4

This folder contains the source code for the Home and Details screens,
navigation, and reusable components required by the assignment. Follow
the steps below **in order**, from a completely empty starting point.

---

## Part A — Install the tools you need (one-time setup)

1. **Install Node.js** (includes npm): go to https://nodejs.org and
   download the "LTS" version for your OS. Run the installer, accepting
   the defaults.
2. **Install a code editor**: [VS Code](https://code.visualstudio.com/)
   is recommended.
3. **Install Git**: https://git-scm.com/downloads — needed to push to
   GitHub.
4. **Create a GitHub account** if you don't have one: https://github.com
5. **Install Expo Go on your phone** — search "Expo Go" in the App
   Store (iPhone) or Play Store (Android). This lets you preview the
   app live on your own phone without building anything.

Check Node and npm installed correctly by opening a terminal
(Command Prompt / Terminal / PowerShell) and running:

```bash
node -v
npm -v
git --version
```

Each should print a version number.

---

## Part B — Create the Expo project

In a terminal, navigate to a folder where you want the project (e.g.
Desktop), then run:

```bash
npx create-expo-app pokedex-app
cd pokedex-app
```

This generates a working blank app and installs React/React Native.

Now install the navigation libraries the assignment requires:

```bash
npx expo install @react-navigation/native @react-navigation/stack @react-navigation/bottom-tabs @react-navigation/drawer
npx expo install react-native-screens react-native-safe-area-context react-native-gesture-handler react-native-reanimated
npx expo install @expo/vector-icons expo-status-bar
```

`expo install` (instead of plain `npm install`) makes sure you get
versions that match your Expo SDK, which avoids a lot of beginner
headaches.

---

## Part C — Copy in the provided code

From this delivered folder, copy the following into your new
`pokedex-app` project, **overwriting** the `App.js` Expo generated for
you:

- `App.js` → replace the one in your project root
- `src/` (the whole folder) → place at your project root, alongside `App.js`

Your project structure should now look like:

```
pokedex-app/
  App.js
  app.json
  package.json
  src/
    navigation/
      TabNavigator.js
      HomeStack.js
    components/
      PokemonCard.js
    screens/
      HomeScreen.js
      DetailsScreen.js
      AboutScreen.js
      SettingsScreen.js
      HelpScreen.js
      LogoutScreen.js
```

---

## Part D — Run it

From inside the `pokedex-app` folder:

```bash
npx expo start
```

A QR code appears in the terminal / browser tab.

- **On your phone**: open the Expo Go app and scan the QR code (Android:
  scan from within Expo Go; iPhone: scan with the regular Camera app,
  it will offer to open in Expo Go).
- **On an emulator** instead, press `a` (Android emulator) or `i` (iOS
  simulator) in the terminal, if you have one set up.

You should see the Pokemon list load, be able to tap a card to see
details, tap hearts to favourite, switch between Home/About tabs, and
open the side drawer for Settings / Help and Support / Logout.

---

## Part E — How this maps to the assignment requirements

| Requirement | Where it lives |
|---|---|
| 1. Expo + React Navigation set up | `package.json`, Part B commands |
| 2. Reusable Pokemon card via props | `src/components/PokemonCard.js` |
| 3. Home screen fetches list, loading/error state | `src/screens/HomeScreen.js` |
| 4. Cards rendered + favourite toggle via state | `HomeScreen.js` + `PokemonCard.js` |
| 5. Stack nav to Details screen with type/height/weight | `src/navigation/HomeStack.js`, `src/screens/DetailsScreen.js` |
| 6. Bottom tabs (Home/About) inside a drawer (Settings/Help/Logout) | `src/navigation/TabNavigator.js`, `App.js` |
| 7. Simple, flat design | All screens use flat colours, no extra graphics |

---

## Part F — Push to GitHub and submit

1. **Create a new repository** on GitHub: go to https://github.com/new,
   give it a name like `dcit324-pokedex-app`, leave it Public or
   Private (either is fine), do **not** check "Add a README" (you
   already have one), then click **Create repository**.

2. GitHub will show you a page with commands. Back in your terminal,
   inside the `pokedex-app` folder, run:

   ```bash
   git init
   git add .
   git commit -m "Initial commit: Pokedex app"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/dcit324-pokedex-app.git
   git push -u origin main
   ```

   Replace `YOUR-USERNAME` and the repo name with your actual GitHub
   username and the repo name you chose. GitHub may prompt you to log
   in the first time — follow the on-screen instructions.

   Note: `create-expo-app` already generates a `.gitignore` that
   excludes `node_modules`, so your repo will be pushed without it
   (this is normal and expected — it keeps the repo small).

3. **Download the ZIP**: on your repository's GitHub page, click the
   green **Code** button, then **Download ZIP**.

4. **Submit**: upload that ZIP file to Sakai under this assignment.

That's it — you now have a working app, a GitHub repo showing your
work, and a submission ready to go.
